#!/bin/bash

$SHARC/spectrum.py initconds.excited --gnuplot plot.gp