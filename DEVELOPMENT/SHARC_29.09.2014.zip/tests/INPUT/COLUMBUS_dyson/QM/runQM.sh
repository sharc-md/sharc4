cd $SCRADIR/TRAJ/QM
$SHARC/SHARC_COLUMBUS.py QM.in >> QM.log 2>> QM.err
err=$?

exit $err