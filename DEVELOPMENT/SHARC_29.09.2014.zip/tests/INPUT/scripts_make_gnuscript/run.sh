#!/bin/bash

$SHARC/make_gnuscript.py 4 0 3 0 1 > traj.gp