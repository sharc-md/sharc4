cd /user/mai/Documents/NewSHARC/SHARC_1.5/DISTRIBUTION/tests/INPUT/scripts_setup_traj/State_2/TRAJ_00001//QM
$SHARC/SHARC_Analytical.py QM.in >> QM.log 2>> QM.err
err=$?

exit $err