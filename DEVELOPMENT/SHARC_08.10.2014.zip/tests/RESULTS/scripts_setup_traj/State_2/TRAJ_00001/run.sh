#/bin/bash

#$-N traj_00001

PRIMARY_DIR=/user/mai/Documents/NewSHARC/SHARC_1.5/DISTRIBUTION/tests/INPUT/scripts_setup_traj/State_2/TRAJ_00001/

cd $PRIMARY_DIR

$SHARC/sharc.x input
