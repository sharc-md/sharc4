#!/bin/bash

$SHARC/Geo.py < Geo.inp > Geo.out