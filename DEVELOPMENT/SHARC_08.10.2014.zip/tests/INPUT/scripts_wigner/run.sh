#!/bin/bash

$SHARC/wigner.py -n 1 freq.molden