#!/bin/bash

$SHARC/laser.x < KEYSTROKES.laser