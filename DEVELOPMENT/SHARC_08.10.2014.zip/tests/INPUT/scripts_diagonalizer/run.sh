#!/bin/bash

$SHARC/diagonalizer.x < input > out