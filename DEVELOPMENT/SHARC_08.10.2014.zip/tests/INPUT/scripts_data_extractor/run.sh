#!/bin/bash

$SHARC/data_extractor.x output.dat